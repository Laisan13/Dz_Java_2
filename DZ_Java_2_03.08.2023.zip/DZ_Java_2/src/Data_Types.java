public class Data_Types {
    public static void main(String[] args) {
        System.out.println("Задание №1");
        char c1 ='G';//char: G
        int i1 = 89;// int: 89
        byte b1  = 4;//byte: 4
        short sh1 = 56;//short: 56
        float f1 = 4.7333436f;//float: 4.7333436
        double d1 = 4.355453532; //double: 4.355453532
        long l1 = 12121;//long: 12121
        System.out.print(c1+","+i1+","+b1+","+sh1+","+l1+","+f1+","+d1+","+l1);
        System.out.println();
        System.out.println();
        System.out.println("Задание №2");
        int i2 = 345;
        System.out.print(i2/100+ ",");
        System.out.print(i2/86+ ",");
        System.out.print(i2%10);
        System.out.println();
        System.out.printf("%s , %d , %s", i2/100, i2/86, i2%10);

        System.out.println();
        System.out.println();

        System.out.println("Дополнительная практика");
        System.out.println("1 задача");
        byte b2 = 127;
        System.out.println(b2);
        //b2 =127+1; при выводе в консоль  выходит ошибка: java: incompatible types: possible lossy conversion from int to byte

        System.out.println();

        System.out.println("2 задача");
        System.out.println(b1*f1);// выводит тоже тип float возможно,  как проверить тип ?


        System.out.println("3 задача");
        char c2 ='A';
        System.out.println(c2+1);// Выводит число 66,











    }
}
